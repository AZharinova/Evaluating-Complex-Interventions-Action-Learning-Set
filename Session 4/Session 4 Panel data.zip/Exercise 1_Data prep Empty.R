install.packages("tidyverse")
install.packages("psych")
install.packages("effectsize")
install.packages("mice")
library(tidyverse)
library(psych)
library(effectsize)
library(mice)

## import dataset


## view the data


## summary statistics


## detecting outliers (visually)


## detecting outliers (statistically)


## dealing with data quality


## imputing missing values