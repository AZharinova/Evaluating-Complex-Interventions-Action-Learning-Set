install.packages("season")
install.packages("Epi")
install.packages("tsModel")
library("tidyverse")
library("season") 
library("Epi")
library("tsModel")
library("zoo") 


###
### Evaluating Complex Interventions. Practical exercise 3.3. ITS (part2 - using glm) ###
#Impact of smoking ban in Sicily on acute coronary episodes
# time = elapsed time since the start of the study
# aces = monthly count of acute coronary episodes
# smokban = smoking ban (0 - before intervention, 1 after)
# pop = total population
# stdpop = age standardised population

sicily <- read.csv("~/projects/DSU course/sicilyDataset.csv") #might have to change directory
sicily


# explore the timeseries


# build ITS  - level change

# check model




# build ITS  - level and slope change 



# Add seasons/months


# poisson model with harmoinic for seasonality


# quasipoisson model with harmoinic for seasonality


# plot final model of choice

